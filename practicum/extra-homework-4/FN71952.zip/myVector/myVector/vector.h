#pragma once

template <class T>
//��� �� ����� �� ������� � ����� �����
class vector
{
private:
	T* data;
	size_t size;
	void erase()
	{
		delete[] data;
	}
	void copy(const vector<T> &other)
	{
		this->size = other.size;
		this->data = new T[other.size];
		for (size_t i = 0; i < this->size; i++)
		{
			this->data[i] = other.data[i];
		}
	}
public:
	vector();
	vector(size_t size, const T &data);
	vector(const vector<T> &other);
	void push_back(const T &elem);
	void pop_back();
	void push_front(const T &elem);
	void pop_front();
	void push_at(int index, const T &elem);
	void pop_at(int index);
	size_t getSize() const;
	bool isEmpty() const;
	void print();
	T& operator[] (size_t index);
	vector<T> operator+ (const T& elem) const;
	vector<T>& operator+= (const T& elem);
	bool operator== (const vector<T>& other) const;
	bool operator!= (const vector<T>& other) const;
	~vector();
};

